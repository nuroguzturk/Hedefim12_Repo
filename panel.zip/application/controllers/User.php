<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('user_model');
    }


    public function index()
    {

        $data['users']=$this->user_model->get_all_users();
        $this->load->view('index',$data);
    }
    public function user_add()
    {
        $data = array(
					'UserTC' => $this->input->post('UserTC'),
					'UserName' => $this->input->post('UserName'),
					'UserSurname' => $this->input->post('UserSurname'),
					'Email' => $this->input->post('Email'),
                    'Password' => $this->input->post('Password'),
                    'Telephone' => $this->input->post('Telephone'),
                    'Gender' => $this->input->post('Gender'),
                    'CityId' => $this->input->post('CityId'),
                    'DateofBirth' => $this->input->post('DateofBirth'),
                    'TaskId' => $this->input->post('TaskId'),
                    'RecorderId' => $this->input->post('RecorderId'),
                    'DateofRecord' => $this->input->post('DateofRecord'),
                    'IsAccept' => $this->input->post('IsAccept'),
				);
        $insert = $this->user_model->user_add($data);
        echo json_encode(array("status" => TRUE));
    }
    public function ajax_edit($id)
    {
        $data = $this->user_model->get_by_id($id);



        echo json_encode($data);
    }

    public function user_update()
    {
        $data = array(
            'UserTC' => $this->input->post('UserTC'),
            'UserName' => $this->input->post('UserName'),
            'UserSurname' => $this->input->post('UserSurname'),
            'Email' => $this->input->post('Email'),
            'Password' => $this->input->post('Password'),
            'Telephone' => $this->input->post('Telephone'),
            'Gender' => $this->input->post('Gender'),
            'CityId' => $this->input->post('CityId'),
            'DateofBirth' => $this->input->post('DateofBirth'),
            'TaskId' => $this->input->post('TaskId'),
            'RecorderId' => $this->input->post('RecorderId'),
            'DateofRecord' => $this->input->post('DateofRecord'),
            'IsAccept' => $this->input->post('IsAccept'),
			);
        $this->user_model->user_update(array('UserId' => $this->input->post('UserId')), $data);
        echo json_encode(array("status" => TRUE));
    }

    public function user_delete($id)
    {
        $this->user_model->delete_by_id($id);
        echo json_encode(array("status" => TRUE));
    }

    public function user_show($id)
    {
        $data = $this->user_model->get_by_id($id);



        echo json_encode($data);
    }



}
