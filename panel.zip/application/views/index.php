<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <?php $this->load->view("includes/inc_meta"); ?>
    <?php $this->load->view("includes/inc_style"); ?>
</head>

<!-- BEGIN BODY -->
<body class="fixed-top">




<!-- BEGIN CONTAINER -->


    <div class="row">

        <?php $this->load->view("includes/inc_sidebar"); ?>



        <div  class="col-sm-10 col-md-10">
            <!-- BEGIN PAGE CONTAINER-->
            <div >
                <?php $this->load->view("includes/inc_page-header"); ?>
                <!-- BEGIN PAGE CONTENT-->
                <div >
                    <div>
                        <?php $this->load->view("user_list"); ?>
                    </div>
                </div>
                <!-- END PAGE CONTENT-->
            </div>
            <!-- END PAGE CONTAINER-->
        </div>

    </div>


    <!-- END CONTAINER -->

</div>
<!-- END CONTAINER -->
    <?php $this->load->view("includes/inc_footer"); ?>

    <?php $this->load->view("includes/inc_script"); ?>


</body>
</html>
