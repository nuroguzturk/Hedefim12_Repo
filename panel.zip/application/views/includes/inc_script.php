<!-- BEGIN JAVASCRIPTS -->
<!-- Load javascripts at bottom, this will reduce page load time -->

<script src="<?php echo base_url("assets"); ?>/js/jquery.nicescroll.js" type="text/javascript"></script>

<script src="<?php echo base_url("assets"); ?>/js/jquery.scrollTo.min.js"></script>

<!-- ie8 fixes -->
<!--[if lt IE 9] -->
<script src="<?php echo base_url("assets"); ?>/js/excanvas.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/respond.js"></script>
<!--[endif]-->

<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->

<!--common script for all pages-->
<script src="<?php echo base_url("assets"); ?>/js/common-scripts.js"></script>


<!-- En son derlenmiş ve minimize edilmiş JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



<!-- END JAVASCRIPTS -->