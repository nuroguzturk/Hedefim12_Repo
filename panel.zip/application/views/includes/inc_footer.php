<!-- BEGIN FOOTER -->
<div id="footer">
    <?php echo date("Y"); ?> &copy; Hedefim12.Com
</div>
<!-- END FOOTER -->