

<link href="<?php echo base_url("assets"); ?>/assets/datatables/css/tablo.bootstrap.min.css" rel="stylesheet" />

<link href="<?php echo base_url("assets"); ?>/assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" />
<link href="<?php echo base_url("assets"); ?>/assets/bootstrap/css/bootstrap-fileupload.css" rel="stylesheet" />
<link href="<?php echo base_url("assets"); ?>/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

<link href="<?php echo base_url("assets"); ?>/css/style.css" rel="stylesheet" />
<link href="<?php echo base_url("assets"); ?>/css/style-responsive.css" rel="stylesheet" />
<link href="<?php echo base_url("assets"); ?>/css/style-default.css" rel="stylesheet" id="style_color" />


<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->


<!-- En son derlenmiş ve minimize edilmiş CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<!-- Opsiyonel tema -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">


