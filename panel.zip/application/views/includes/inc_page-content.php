<!-- BEGIN BLANK PAGE PORTLET-->
<div class="widget red">
    <div class="widget-title">
        <h4><i class="icon-edit"></i> Soru Ekleme Bölümü </h4>
        <span class="tools">
                               <a href="javascript:;" class="icon-chevron-down"></a>
                               <a href="javascript:;" class="icon-remove"></a>
                           </span>
    </div>
    <div class="widget-body">

    <?php $this->load->view("panel"); ?>

    </div>
</div>
<!-- END BLANK PAGE PORTLET-->