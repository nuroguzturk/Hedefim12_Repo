<!DOCTYPE html>
<html lang="en">
<head>
    <title> Hedefim12.Com - Kullanıcı Kaydı </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php $this->load->view("inc_forms/inc_form-style"); ?>

</head>
<body class="woodbg">

<div class="smart-wrap">
    <div class="smart-forms smart-container wrap-3">

        <div class="form-header header-red">
            <h4><i class="fa fa-pencil-square"></i>Hesap Oluştur</h4>
        </div><!-- end .form-header section -->

        <form method="post" action="/" id="account">
            <div class="form-body theme-red">

                <label for="names" class="field-label">Kullanıcı Bilgileri</label>
                <div class="frm-row">

                    <div class="section colm colm6">
                        <label class="field prepend-icon">
                            <input type="text" name="firstname" id="firstname" class="gui-input" placeholder="İsminiz...">
                            <span class="field-icon"><i class="fa fa-user"></i></span>
                        </label>
                    </div><!-- end section -->

                    <div class="section colm colm6">
                        <label class="field prepend-icon">
                            <input type="text" name="lastname" id="lastname" class="gui-input" placeholder="Soyisminiz...">
                            <span class="field-icon"><i class="fa fa-user"></i></span>
                        </label>
                    </div><!-- end section -->

                </div><!-- end frm-row section -->



                <div class="section">
                    <label for="password" class="field-label">Şifre oluştur</label>
                    <label class="field prepend-icon">
                        <input type="password" name="password" id="password" class="gui-input">
                        <span class="field-icon"><i class="fa fa-lock"></i></span>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="confirmPassword" class="field-label">Şifre tekrar</label>
                    <label class="field prepend-icon">
                        <input type="password" name="confirmPassword" id="confirmPassword" class="gui-input">
                        <span class="field-icon"><i class="fa fa-unlock-alt"></i></span>
                    </label>
                </div><!-- end section -->

                <label for="birthday" class="field-label">Doğum tarihiniz</label>
                <div class="frm-row">
                    <div class="section colm colm5">
                        <label for="month" class="field select">
                            <select id="month" name="month">
                                <option value="01">01 - Ocak</option>
                                <option value="02">02 - Şubat</option>
                                <option value="03">03 - Mart</option>
                                <option value="04">04 - Nisan</option>
                                <option value="05">05 - Mayıs</option>
                                <option value="06">06 - Haziran</option>
                                <option value="07">07 - Temmuz</option>
                                <option value="08">08 - Ağustos</option>
                                <option value="09">09 - Eylül</option>
                                <option value="10">10 - Ekim</option>
                                <option value="11">11 - Kasım</option>
                                <option value="12">12 - Aralık</option>
                            </select>
                            <i class="arrow double"></i>
                        </label>
                    </div><!-- end section -->

                    <div class="section colm colm3">
                        <label for="day" class="field select">
                             <select id="day" name="day">
                                            <option value="01">01</option>
                                            <option value="02">02</option>
                                            <option value="03">03</option>
                                            <option value="04">04</option>
                                            <option value="05">05</option>
                                            <option value="06">06</option>
                                            <option value="07">07</option>
                                            <option value="08">08</option>
                                            <option value="09">09</option>
                                            <option value="10">10</option>
                                            <option value="11">11</option>
                                            <option value="12">12</option>
                                            <option value="01">13</option>
                                            <option value="02">14</option>
                                            <option value="03">15</option>
                                            <option value="04">16</option>
                                            <option value="05">17</option>
                                            <option value="06">18</option>
                                            <option value="07">19</option>
                                            <option value="08">20</option>
                                            <option value="09">21</option>
                                            <option value="10">22</option>
                                            <option value="11">23</option>
                                            <option value="12">24</option>
                                            <option value="04">25</option>
                                            <option value="05">26</option>
                                            <option value="06">27</option>
                                            <option value="07">28</option>
                                            <option value="08">29</option>
                                            <option value="09">30</option>
                                            <option value="10">31</option>
                                        </select>
                                        <i class="arrow double"></i>
                        </label>
                    </div><!-- end section -->

                    <div class="section colm colm3">
                        <label for="year" class="field">
                            <input type="text" name="year" id="year" class="gui-input" placeholder="Yıl...">
                        </label>
                    </div><!-- end section -->

                </div><!-- end .frm-row section -->

                <div class="section">
                    <label for="location" class="field-label">İl </label>
                    <label class="field select">
                        <select id="location" name="location">

                                <option value="0">Seçiniz</option>
                                <option value="1">Adana</option>
                                <option value="2">Adıyaman</option>
                                <option value="3">Afyonkarahisar</option>
                                <option value="4">Ağrı</option>
                                <option value="5">Amasya</option>
                                <option value="6">Ankara</option>
                                <option value="7">Antalya</option>
                                <option value="8">Artvin</option>
                                <option value="9">Aydın</option>
                                <option value="10">Balıkesir</option>
                                <option value="11">Bilecik</option>
                                <option value="12">Bingöl</option>
                                <option value="13">Bitlis</option>
                                <option value="14">Bolu</option>
                                <option value="15">Burdur</option>
                                <option value="16">Bursa</option>
                                <option value="17">Çanakkale</option>
                                <option value="18">Çankırı</option>
                                <option value="19">Çorum</option>
                                <option value="20">Denizli</option>
                                <option value="21">Diyarbakır</option>
                                <option value="22">Edirne</option>
                                <option value="23">Elazığ</option>
                                <option value="24">Erzincan</option>
                                <option value="25">Erzurum</option>
                                <option value="26">Eskişehir</option>
                                <option value="27">Gaziantep</option>
                                <option value="28">Giresun</option>
                                <option value="29">Gümüşhane</option>
                                <option value="30">Hakkâri</option>
                                <option value="31">Hatay</option>
                                <option value="32">Isparta</option>
                                <option value="33">Mersin</option>
                                <option value="34">İstanbul</option>
                                <option value="35">İzmir</option>
                                <option value="36">Kars</option>
                                <option value="37">Kastamonu</option>
                                <option value="38">Kayseri</option>
                                <option value="39">Kırklareli</option>
                                <option value="40">Kırşehir</option>
                                <option value="41">Kocaeli</option>
                                <option value="42">Konya</option>
                                <option value="43">Kütahya</option>
                                <option value="44">Malatya</option>
                                <option value="45">Manisa</option>
                                <option value="46">Kahramanmaraş</option>
                                <option value="47">Mardin</option>
                                <option value="48">Muğla</option>
                                <option value="49">Muş</option>
                                <option value="50">Nevşehir</option>
                                <option value="51">Niğde</option>
                                <option value="52">Ordu</option>
                                <option value="53">Rize</option>
                                <option value="54">Sakarya</option>
                                <option value="55">Samsun</option>
                                <option value="56">Siirt</option>
                                <option value="57">Sinop</option>
                                <option value="58">Sivas</option>
                                <option value="59">Tekirdağ</option>
                                <option value="60">Tokat</option>
                                <option value="61">Trabzon</option>
                                <option value="62">Tunceli</option>
                                <option value="63">Şanlıurfa</option>
                                <option value="64">Uşak</option>
                                <option value="65">Van</option>
                                <option value="66">Yozgat</option>
                                <option value="67">Zonguldak</option>
                                <option value="68">Aksaray</option>
                                <option value="69">Bayburt</option>
                                <option value="70">Karaman</option>
                                <option value="71">Kırıkkale</option>
                                <option value="72">Batman</option>
                                <option value="73">Şırnak</option>
                                <option value="74">Bartın</option>
                                <option value="75">Ardahan</option>
                                <option value="76">Iğdır</option>
                                <option value="77">Yalova</option>
                                <option value="78">Karabük</option>
                                <option value="79">Kilis</option>
                                <option value="80">Osmaniye</option>
                                <option value="81">Düzce</option>

                        </select>
                        <i class="arrow double"></i>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="gender" class="field-label">Cinsiyet </label>
                    <label class="field select">
                        <select id="gender" name="gender">
                            <option value="">Seçiminiz...</option>
                            <option value="male">Erkek</option>
                            <option value="female">Bayan</option>
                            <option value="other">Diğer</option>
                        </select>
                        <i class="arrow double"></i>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="email" class="field-label">Email </label>
                    <label class="field prepend-icon">
                        <input type="email" name="email" id="email" class="gui-input" placeholder="isminiz@domain.com...">
                        <span class="field-icon"><i class="fa fa-envelope"></i></span>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="mobile" class="field-label">Cep telefonu </label>
                    <label class="field prepend-icon">
                        <input type="tel" name="mobile" id="mobile" class="gui-input" placeholder="+90 ">
                        <span class="field-icon"><i class="fa fa-phone-square"></i></span>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="kullanici_sekli" class="field-label">Kullanıcı şekli </label>
                    <label class="field select">
                        <select id="kullanici_sekli" name="kullanici_sekli">
                            <option value="">Seçiminiz...</option>
                            <option value="oyonetim">Okul Yönetimi</option>
                            <option value="ogretmen">Öğretmen</option>
                            <option value="ogrenci">Öğrenci</option>
                            <option value="veli">Veli</option>
                        </select>
                        <i class="arrow double"></i>
                    </label>
                </div><!-- end section -->

                <div class="section">
                    <label for="verify" class="field-label">İşlemin sonucunu yazınız </label>
                    <div class="smart-widget sm-left sml-80">
                        <label class="field prepend-icon">
                            <input type="text" name="verify" id="verify" class="gui-input" placeholder="Soldaki işlemin sonucu">
                            <span class="field-icon"><i class="fa fa-shield"></i></span>
                        </label>
                        <label for="verify" class="button">4 + 12</label>
                    </div><!-- end .smart-widget section -->
                </div><!-- end section -->

                <div class="section">
                    <label class="option option-red">
                        <input type="checkbox" name="check1">
                        <span class="checkbox"></span>
                        Kabul ediyorum <a href="#" class="smart-link"> kullanıcı şartnamesini </a>
                    </label>
                </div><!-- end section -->

            </div><!-- end .form-body section -->
            <div class="form-footer">
                <button type="submit" class="button btn-red">Hesap oluştur</button>
            </div><!-- end .form-footer section -->
        </form>

    </div><!-- end .smart-forms section -->
</div><!-- end .smart-wrap section -->
</body>
</html>