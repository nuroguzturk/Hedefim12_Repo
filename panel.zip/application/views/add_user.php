<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="tr">

<head>
    <?php $this->load->view("includes/inc_meta"); ?>
    <?php $this->load->view("includes/inc_style"); ?>
</head>

<!-- BEGIN BODY -->
<body class="fixed-top">

<?php $this->load->view("includes/inc_header"); ?>


<!-- BEGIN CONTAINER -->
<div id="container" class="row-fluid">

    <?php $this->load->view("includes/inc_sidebar"); ?>

    <!-- BEGIN PAGE -->
    <div id="main-content">
        <!-- BEGIN PAGE CONTAINER-->
        <div class="container-fluid">
            <?php $this->load->view("includes/inc_page-header"); ?>
            <!-- BEGIN PAGE CONTENT-->
            <div class="row-fluid">
                <div class="span12">
                    <?php $this->load->view("book_view"); ?>
                </div>
            </div>
            <!-- END PAGE CONTENT-->
        </div>
        <!-- END PAGE CONTAINER-->
    </div>
    <!-- END PAGE -->
</div>
<!-- END CONTAINER -->

</div>
<!-- END CONTAINER -->
<?php $this->load->view("includes/inc_footer"); ?>

<?php $this->load->view("includes/inc_script"); ?>


</body>
</html>