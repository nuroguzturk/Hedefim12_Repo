<link rel="stylesheet" type="text/css"  href="<?php echo base_url("assets"); ?>/sform/css/smart-forms.css">
<link rel="stylesheet" type="text/css"  href="<?php echo base_url("assets"); ?>/sform/css/smart-themes/red.css">
<link rel="stylesheet" type="text/css"  href="<?php echo base_url("assets"); ?>/sform/css/font-awesome.min.css">


<!--[if lte IE 9]-->
<script type="text/javascript" src="<?php echo base_url("assets"); ?>/sform/js/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url("assets"); ?>/sform/js/jquery.placeholder.min.js"></script>
<![endif]-->

<!--[if lte IE 8]-->
<link type="text/css" rel="stylesheet" href="<?php echo base_url("assets"); ?>/sform/css/smart-forms-ie8.css">
<![endif]-->